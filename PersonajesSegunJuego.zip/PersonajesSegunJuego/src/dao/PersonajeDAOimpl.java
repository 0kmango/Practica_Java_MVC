
package dao;

import java.util.List;
import model.Personaje;
import persistencia.RegistroPersonajes;

public class PersonajeDAOimpl implements CRUD<Personaje>{

    @Override
    public void create(Personaje t) {
        RegistroPersonajes.agregar(t);
    }

    @Override
    public List<Personaje> read() {
        return RegistroPersonajes.getPersonajes();
    }

    @Override
    public void remove(Personaje t) {
        RegistroPersonajes.eliminar(t.getId());
    }
    
}
