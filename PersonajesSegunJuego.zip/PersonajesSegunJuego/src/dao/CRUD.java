
package dao;

import java.util.List;

public interface CRUD<T> {
    
    public void create(T t);
    public List<T>read();
    public void remove(T t);
    
    
}
