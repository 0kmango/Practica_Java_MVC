
package controlador;

import java.util.ArrayList;
import model.Personaje;
import vista.VistaMensaje;
import vista.vistaPrincipal;

public class Controlador {
    
    private vistaPrincipal vista;
    private Personaje modelo;

    public Controlador(vistaPrincipal vista) {
        this.vista = vista;
        modelo = new Personaje();
    }
    
    
    public void inicializar(){
        vista.getBtnAgregar().addActionListener(e -> agregar());
        vista.getBtnEliminar().addActionListener(e -> eliminar());
        vista.getBtnLimpiar().addActionListener(e -> limpiar());
        vista.getBtnSalir().addActionListener(e -> salir());
        
        vista.getCbJuego().removeAllItems();
        vista.getCbJuego().addItem("GTA V");
        vista.getCbJuego().addItem("Valorant");
        vista.getCbJuego().addItem("Fortnite");
        vista.getCbJuego().addItem("Warframe");
        
        vista.getCbPersonaje().removeAllItems();
        vista.getCbPersonaje().addItem("");
        vista.getCbPersonaje().addItem("Trevor");
        vista.getCbPersonaje().addItem("Franklin");
        vista.getCbPersonaje().addItem("Michael");
        vista.getCbPersonaje().addItem("Amanda");
        vista.getCbPersonaje().addItem("Tracey");
        vista.getCbPersonaje().addItem("Jimmy");
        
        vista.getCbJuego().addActionListener(e -> setearControles());
        
        vista.setVisible(true);
    }

    public void setearControles(){
        ArrayList<String>opciones = new ArrayList();
        
        String juego = (String) vista.getCbJuego().getSelectedItem();
        
        if(juego.equalsIgnoreCase("gta v")){
            opciones.add("");
            opciones.add("Trevor");
            opciones.add("Franklin");
            opciones.add("Michael");
            opciones.add("Amanda");
            opciones.add("Tracey");
            opciones.add("Jimmy");
            
        } else if(juego.equalsIgnoreCase("valorant")){
           opciones.add("");
           opciones.add("Brimstone");
           opciones.add("Sage");
           opciones.add("Raze");
           opciones.add("Sova");
           opciones.add("Killjoy");
           opciones.add("Kay/o");
        
        } else if(juego.equalsIgnoreCase("Fortnite")){
            opciones.add("");
            opciones.add("Jonesy");
            opciones.add("Bananin");
            opciones.add("Palito Pescado");
            opciones.add("Renegada");
            opciones.add("Chica Zombie");
            opciones.add("John Wick");
            
            
        } else if(juego.equalsIgnoreCase("Warframe")){
            opciones.add("");
            opciones.add("Frost");
            opciones.add("Excalibur");
            opciones.add("Gauss");
            opciones.add("Mag");
            opciones.add("Yareli");
            opciones.add("Wisp");
        }
        
        vista.getCbPersonaje().removeAllItems();
        for (String opc : opciones) {
            vista.getCbPersonaje().addItem(opc);
        }
        
        
    }
    
    private void agregar() {
        try {
            int id = Integer.parseInt(vista.getTxtId().getText());
            String nombre = (String) vista.getCbPersonaje().getSelectedItem();
            String juego = (String) vista.getCbJuego().getSelectedItem();
            
            modelo = new Personaje(id, nombre, juego);
            modelo.agregar();
            
            VistaMensaje.verMensajeInfo(null, "Personaje Agregado.");
            limpiar();
            vista.verRegistros((ArrayList<Personaje>) modelo.listar());
            
        } catch (NumberFormatException numberFormatException) {
            VistaMensaje.verMensajeError(null, "Error. Personaje NO agregado.");
        }
    }

    private void eliminar() {
        try {
            int id = Integer.parseInt(vista.getTxtId().getText());
            
            modelo = new Personaje();
            modelo.eliminar();
            modelo.setId(id);
            
            VistaMensaje.verMensajeInfo(null, "Personaje ELiminado.");
            modelo.listar();
            limpiar();
        } catch (NumberFormatException numberFormatException) {
            VistaMensaje.verMensajeError(null, "Error. Personaje NO eliminado.");
        }
        
    }

    private void limpiar() {
        vista.getTxtId().setText("");
        vista.getCbJuego().setSelectedIndex(0);
        vista.getCbPersonaje().setSelectedIndex(0);
        
        vista.getTxtId().requestFocus();
    }

    private void salir() {
        vista.dispose();
        System.exit(0);
    }
    
    
}
