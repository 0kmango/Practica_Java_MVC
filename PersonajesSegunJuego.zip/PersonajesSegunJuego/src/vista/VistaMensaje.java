
package vista;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class VistaMensaje {
    
    public static void verMensajeError(JDialog parent, String mensaje){
        JOptionPane.showMessageDialog(parent, mensaje, 
                "Descripcion Error", JOptionPane.ERROR_MESSAGE);
    }
    
    public static void verMensajeInfo(JDialog parent, String mensaje){
        JOptionPane.showMessageDialog(parent, mensaje, 
                "Informacion", JOptionPane.INFORMATION_MESSAGE);
    }
    
}
