
package personajessegunjuego;

import controlador.Controlador;
import vista.vistaPrincipal;

public class Main {

    public static void main(String[] args) {

        vistaPrincipal vista = new vistaPrincipal();
        Controlador controlador = new Controlador(vista);
        controlador.inicializar();
        
        
    }
    
}
