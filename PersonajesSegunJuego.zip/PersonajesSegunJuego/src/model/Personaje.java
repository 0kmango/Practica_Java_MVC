
package model;

import dao.PersonajeDAOimpl;
import java.util.List;

public class Personaje {
    
    private int id;
    private String nombre;
    private String juego;

    public Personaje() {
    }
    
    public Personaje(int id, String nombre, String juego) {
        this.id = id;
        this.nombre = nombre;
        this.juego = juego;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getJuego() {
        return juego;
    }

    public void setJuego(String juego) {
        this.juego = juego;
    }
    
    
    
    //METODOS DAO
    public void agregar(){
        PersonajeDAOimpl dao = new PersonajeDAOimpl();
        dao.create(this);
    }
    
    public void eliminar(){
        PersonajeDAOimpl dao = new PersonajeDAOimpl();
        dao.remove(this);
    }
    
    public List<Personaje>listar(){
        PersonajeDAOimpl dao = new PersonajeDAOimpl();
        return dao.read();
    }
    
    
    
}
