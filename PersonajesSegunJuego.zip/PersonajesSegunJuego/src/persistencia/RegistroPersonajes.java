
package persistencia;

import java.util.ArrayList;
import java.util.List;
import model.Personaje;

public class RegistroPersonajes {
    
    public static List<Personaje>lista = new ArrayList<>();
    
    public static boolean agregar(Personaje nuevo){
        if(nuevo == null || nuevo.getId() == 0){
            return false;
        }
        return lista.add(nuevo);
    }
    
    public static boolean eliminar(int id){
        for (Personaje pj : lista) {
            if(pj.getId() == id){
                lista.remove(pj);
            }
        }
        return false;
    }
    
    
    public static List<Personaje>getPersonajes(){
        return lista;
    }
    
    
    
}
