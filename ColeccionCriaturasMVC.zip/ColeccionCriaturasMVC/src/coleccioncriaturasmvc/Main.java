
package coleccioncriaturasmvc;

import controlador.ControladorCriaturas;
import vista.VistaCriatura;

public class Main {

    public static void main(String[] args) {

       VistaCriatura vista = new VistaCriatura();
        ControladorCriaturas controlador = new ControladorCriaturas(vista);
        controlador.inicializar();
        
        
    }
    
}
