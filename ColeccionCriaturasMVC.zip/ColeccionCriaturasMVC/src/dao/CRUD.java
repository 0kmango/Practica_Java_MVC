
package dao;

import java.util.ArrayList;

public interface CRUD<T> {
    
    public void create(T t)throws java.lang.ClassNotFoundException, java.lang.InstantiationException, java.lang.IllegalAccessException, java.lang.Exception;
    public ArrayList<T> read()throws java.lang.ClassNotFoundException, java.lang.InstantiationException, java.lang.IllegalAccessException, java.lang.Exception;
    
    
}
