
package dao;

import java.util.ArrayList;
import modelo.Criatura;
import modelo.RegistroCriaturas;

public class CriaturaDAOimpl implements CRUD<Criatura> {

    @Override
    public void create(Criatura t) throws java.lang.ClassNotFoundException, java.lang.InstantiationException, java.lang.IllegalAccessException, java.lang.Exception {
        RegistroCriaturas.agregar(t);
    }

    @Override
    public ArrayList<Criatura> read() throws java.lang.ClassNotFoundException, java.lang.InstantiationException, java.lang.IllegalAccessException, java.lang.Exception {
        return RegistroCriaturas.getCriaturas();
    }
    
    
    
}
