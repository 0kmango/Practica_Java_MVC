
package modelo;

import dao.CriaturaDAOimpl;
import java.util.ArrayList;

public class Criatura {
    
    private String nombre;
    private int nivelPoder;

    public Criatura() {
    }

    public Criatura(String nombre, int nivelPoder) {
        setNombre(nombre);
        setNivelPoder(nivelPoder);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(!nombre.isEmpty())this.nombre = nombre;
        else throw new IllegalArgumentException("Nombre invalido.");
    }

    public int getNivelPoder() {
        return nivelPoder;
    }

    public void setNivelPoder(int nivelPoder) {
        if(nivelPoder >= 0 && nivelPoder <= 100)this.nivelPoder = nivelPoder;
        else throw new IllegalArgumentException("Poder debe estar entre 0 y 100.");
    }
    
    
    //METODOS
    @Override
    public boolean equals(Object o){
        if(o instanceof Criatura){
            return this.nombre.equalsIgnoreCase(((Criatura)o).nombre);
        }
        return false;
    }
    
    
    //METODOS DAO
    public void agregar() throws java.lang.ClassNotFoundException, java.lang.InstantiationException, java.lang.IllegalAccessException, java.lang.Exception{
        CriaturaDAOimpl dao = new CriaturaDAOimpl();
        dao.create(this);
    }
    
    public ArrayList<Criatura>leer()throws java.lang.ClassNotFoundException, java.lang.InstantiationException, java.lang.IllegalAccessException, java.lang.Exception {
        CriaturaDAOimpl dao = new CriaturaDAOimpl();
        return dao.read();
    }
    
    
    
    
    
    
    
    
    
    
}
