
package modelo;

public class Dragon extends Criatura {
    
    private String tipoFuego;

    public Dragon() {
    }

    public Dragon(String tipoFuego, String nombre, int nivelPoder) {
        super(nombre, nivelPoder);
        setTipoFuego(tipoFuego);
    }

    public String getTipoFuego() {
        return tipoFuego;
    }

    public void setTipoFuego(String tipoFuego) {
        if(tipoFuego.equalsIgnoreCase("Fuego") ||
           tipoFuego.equalsIgnoreCase("Veneno") || 
           tipoFuego.equalsIgnoreCase("Rayo") || 
           tipoFuego.equalsIgnoreCase("Hielo")){
            
         this.tipoFuego = tipoFuego;   
        }
        else throw new IllegalArgumentException("Tipo de fuego no valido.");
    }
    
    
    

    
    
    
}
