
package modelo;

import java.util.ArrayList;

public class RegistroCriaturas {
    
    private static ArrayList<Criatura> criaturas = new ArrayList();
    
    public static void agregar(Criatura nueva) throws Exception {
        if(!criaturas.contains(nueva)){
            criaturas.add(nueva);
        }
        else throw new Exception("Criatura repetida.");
    }
    
    public static ArrayList<Criatura>getCriaturas(){
        return criaturas;
    }
    
    
}
