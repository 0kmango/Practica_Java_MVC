
package modelo;

public class HechiceroOscuro extends Criatura {
    
    private String grimorio;

    public HechiceroOscuro() {
    }

    public HechiceroOscuro(String grimorio, String nombre, int nivelPoder) {
        super(nombre, nivelPoder);
        setGrimorio(grimorio);
    }

    public String getGrimorio() {
        return grimorio;
    }

    public void setGrimorio(String grimorio) {
        if(grimorio.equalsIgnoreCase("Conjuro") ||
           grimorio.equalsIgnoreCase("Ritual") ||
           grimorio.equalsIgnoreCase("Magia Prohibida")){
            
           this.grimorio = grimorio; 
        }
        else throw new IllegalArgumentException("Grimorio Invalido.");
    }
    
    
}
