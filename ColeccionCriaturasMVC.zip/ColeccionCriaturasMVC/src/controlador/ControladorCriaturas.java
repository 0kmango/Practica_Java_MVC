
package controlador;

import java.util.ArrayList;
import modelo.Criatura;
import modelo.Dragon;
import modelo.HechiceroOscuro;
import vista.VistaCriatura;
import vista.VistaMensaje;

public class ControladorCriaturas {
    
    private VistaCriatura vista;
    private Criatura modelo;

    public ControladorCriaturas(VistaCriatura vista) {
        this.vista = vista;
        modelo = new Criatura();
    }
    
    public void inicializar(){
        
        //Limpiar y agregar items de combobox
        vista.getCbTipo().removeAllItems();
        vista.getCbTipo().addItem("");
        vista.getCbTipo().addItem("Dragon");
        vista.getCbTipo().addItem("Hechicero Oscuro");

        vista.getCbCaracteristica().removeAllItems();
        vista.getCbCaracteristica().addItem("");
        vista.getCbCaracteristica().addItem("Fuego");
        vista.getCbCaracteristica().addItem("Hielo");
        vista.getCbCaracteristica().addItem("Rayo");
        vista.getCbCaracteristica().addItem("Veneno");
        
        vista.getCbTipo().addActionListener(e -> setearControles());
        
        
        //BOTONES
        vista.getBtnAgregar().addActionListener(e -> agregar());
        vista.getBtnLimpiar().addActionListener(e -> limpiar());
        
        vista.setVisible(true);
        
    }
    
    public void setearControles(){
        ArrayList<String>opciones = new ArrayList();
        
        String tipo = (String) vista.getCbTipo().getSelectedItem();
        
        if(tipo.equalsIgnoreCase("dragon")){
            vista.getLbCaracteristica().setText("TIPO FUEGO");
            opciones.add("");
            opciones.add("Fuego");
            opciones.add("Hielo");
            opciones.add("Veneno");
            opciones.add("Rayo");
            
        } else{
            vista.getLbCaracteristica().setText("GRIMORIO");
            opciones.add("");
            opciones.add("Conjuro");
            opciones.add("Ritual");
            opciones.add("Magia Prohibida");
        }
        
        vista.getCbCaracteristica().removeAllItems();
        for (String opc : opciones) {
            vista.getCbCaracteristica().addItem(opc);
        }
    }

    private void agregar() {
        try {
            String nombre = vista.getTfNombre().getText();
            int nivelPoder = Integer.parseInt(vista.getTfNivelPoder().getText());
            String tipo = (String) vista.getCbTipo().getSelectedItem();
            
            if (tipo.equalsIgnoreCase("dragon")) {
                String tipoFuego = (String) vista.getCbCaracteristica().getSelectedItem();
                modelo = new Dragon(tipoFuego, nombre, nivelPoder);
                
            } else {
                String grimorio = (String) vista.getCbCaracteristica().getSelectedItem();
                modelo = new HechiceroOscuro(grimorio, nombre, nivelPoder);
                
            }
            
            modelo.agregar();
            
            VistaMensaje.verMensajeInfo(null, "Criatura agregada.");
            limpiar();
            vista.verRegistros(modelo.leer());
            
        } catch (IllegalAccessException ex) {
            VistaMensaje.verMensajeError(null, "Error. No agregado.\n" + ex.getMessage());
            
        } catch (Exception ex) {
            VistaMensaje.verMensajeError(null, "Problema al agregar criatura\n" + ex.getMessage());
        }

      
       
    }

    private void limpiar() {
        vista.getTfNombre().setText("");
        vista.getTfNivelPoder().setText("0");
        vista.getCbTipo().setSelectedIndex(0);
        vista.getCbCaracteristica().setSelectedIndex(0);
        
        vista.getTfNombre().requestFocus();
    }
    
    
    
    
    
}
